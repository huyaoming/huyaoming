
# XPath，全称XML Path Language，即XML路径语言，它是一门在XML文档中查找信息的语言，它
# 最初是用来搜寻XML文档的，但是它同样适用于HTML文档的搜索
# XPath的选择功能十分强大，它提供了非常简明的路径选择表达式，另外，它还提供了超过100个
# 内建函数，用于字符串、数值、时间的匹配以及节点、序列的处理等，几乎所有我们想要定位的节
# 点，都可以用XPath来选择
# 作用：
# 1.实现标签的定位：实例化一个etree的对象，且需要将被解析的页面源码数据加载到该对象中。
# 2.调用etree对象中的xpath方法结合着xpath表达式实现标签的定位和内容的捕获。

# import lxml.etree
# import lxml
#
# text = ''''
# <div>
#     <ul>
#         <li class="item-0"><a href="link1.html">first item</a></li>
#         <li class="item-1"><a href="link2.html">second item</a></li>
#         <li class="item-inactive"><a href="link3.html">third item</a></li>
#         <li class="item-1"><a href="link4.html">fourth item</a></li>
#         <li class="item-0"><a href="link5.html">fifth item</a></li>
#     </ul>
# </div>
# '''
# html = lxml.etree.HTML(text)
# print(html)
# result = lxml.etree.tostring(html)
# print(result.decode("utf-8"))
# lis = html.xpath("//li")        #可以将<li>标签获取到
# print(lis)
# for li in lis:
#     print(li.xpath("./*/text()"))     #获取文本信息
#     print(li.xpath("./a/@href"))      #获取文本信息
import os

import lxml.etree

# html = lxml.etree.parse("b.html")     #parse进行转换为html对象
# print(html)
# result = html.xpath("/html")
# print(result)
# result = html.xpath("/html/body")
# print(result)
# result = html.xpath("/html//*/li/a/text()")     #获取到所有的li标签下的数据
# print(result)
# result = html.xpath("//html/*/ul/li/a/text()")  #获取到ul下所有的li标签下的数据
# print(result)


#运算符学习
from lxml import etree

# text = '''
#     <li class='li li-first' name='item'><a href='link.html'>first item</a></li>
#     <li class='fi-first' name='item'><a href='link.html'>second item</a></li>
#     <li name='item0'><a href='link.html'>thrid item</a></li>
#
# '''
# html = etree.HTML(text)
# result = html.xpath("//li[contains(@class,'fi') and @name='item']/a/text()")       #contains表示包含
# print(result)
# result = html.xpath("//li[@class='li li-first' and @name='item']/a/text()")        #and表示同时存在
# print(result)
# result = html.xpath("//li[contains(@class,'li') or @name='item0']/a/text()")       #or表示两者存在其一即可
# print(result)



#获取子节点
text = '''
    <div>
        <ul>
            <li class="item-0, item-7" name="name1"><a href="link1.html"><span>first item</span></a></li>
            <li class="item-1"><a href="link2.html"><span>second item</span></a></li>
            <li class="item-inactive"><a href="link3.html"><span>third item</span></a></li>
            <li class="item-1"><a href="link4.html"><span>fourth item</span></a></li>
            <li class="item-0"><a href="link5.html"><span>fifth item</span></a></li>
        </ul>
    </div>
'''
html = lxml.etree.HTML(text)               #转换html格式时，会增减html,body节点
# result = html.xpath("//li/parent::*")      # *表示所有的节点，获取父节点的数据
# print(result)
# print(lxml.etree.tostring(html).decode("utf-8"))
# result = html.xpath("//li/ancestor::*")     #获取到祖先节点的数据
# print(result)
# result = html.xpath("//li/ancestor::ul")
# print(result)
# result = html.xpath("//li/attribute::*")   #获取属性的数据
# print(result)
# result = html.xpath("//li[1]/attribute::*")  #[1]表示第一个li标签
# print(result)
# result = html.xpath("//li[1]/attribute::class") #[1]表示的是第一个li的class
# print(result)
# result = html.xpath("//li[1]/child::*")
# print(result)
# result = html.xpath("//li/child::*")
# print(result)
# result = html.xpath("//li/child::*[@href='link5.html']")[0]
# print(result)
# print(lxml.etree.tostring(result).decode("utf-8"))
#获取子孙节点
# result = html.xpath("//li/descendant::*")   #获取所有li的子孙节点
# print(result)
# result = html.xpath("//li/descendant::*[@class='span3']")
# print(result)
#print(lxml.etree.tostring(result[0]).decode("utf-8"))
# result = html.xpath("//li[1]/following::*")      #following获取当前节点下的兄弟节点以及其他兄弟节点的子孙节点
# print(result)
# result = html.xpath("//li[4]/following::*")
# print(result)
# result = html.xpath("//li[1]/following-sibling::*")      #following-sibling只获取当前节点下的兄弟节点，不包括子孙节点
# print(result)
# result = html.xpath("//li[4]/following-sibling::*")
# print(result)






#实例：爬取小说
import requests
import lxml
import os

url = "https://www.17k.com/list/3421822.html"
headers = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36"
}
resp = requests.get(url,headers=headers)
# print(resp.text)
resp.encoding="utf-8"
text = resp.text
html = lxml.etree.HTML(text)
a_s = html.xpath("//*/dl[@class='Volume']/dd/a")
baseurl = url.rsplit("/",2)[0]     #从右边开始进行切割，最大切割数为2
# print(baseurl)
for a in a_s:
    href = a.xpath("./@href")[0]
    bookurl = baseurl+href     #小说的路径
    bookresp = requests.get(bookurl,headers=headers)
    bookresp.encoding="utf-8"
    booktext = bookresp.text
    bookhtml = lxml.etree.HTML(booktext)
    title = bookhtml.xpath("//*[@class='readArea']/div/h1/text()")[0]
    content = bookhtml.xpath("//*[@class='readArea']/div/div[@class='p']/p/text()")
    bookcontent = "\n".join(content)
    # print(title)
    # print(bookcontent)
    # break
    with open("book"+os.sep+title.strip()+".txt","w",encoding="utf-8") as f:
        f.write(bookcontent)
print("加载完成！")

