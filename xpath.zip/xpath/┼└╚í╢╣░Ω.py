import os

import lxml
import requests
import re
from lxml import etree

url = "https://movie.douban.com/top250"

headers = {
"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36"
}
resp = requests.get(url,headers=headers)
resp.encoding="utf-8"
text = resp.text
html = lxml.etree.HTML(text)
lis = html.xpath("//ol/li")
for li in lis:
    src = li.xpath("./div/div/a/img/@src")[0]
    title = li.xpath("./div/div/div/a/span[1]/text()")[0]
    imgresp = requests.get(src,headers=headers)
    with open("img_Xpath"+os.sep+title+".jpg","wb") as f:
        f.write(imgresp.content)

print("加载完成!")
